﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gNAMEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rATINGDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cATEGORYDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dEVELOPDATEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gAMEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rentalDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rentalDataSet = new WindowsFormsApp1.rentalDataSet();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.gAMETableAdapter = new WindowsFormsApp1.rentalDataSetTableAdapters.GAMETableAdapter();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gAMEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(32, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(32, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(32, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(32, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(32, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 23);
            this.label5.TabIndex = 4;
            this.label5.Text = "Birth Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(32, 239);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "State";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Window;
            this.label7.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label7.Location = new System.Drawing.Point(32, 366);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 23);
            this.label7.TabIndex = 8;
            this.label7.Text = "Street";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(32, 325);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 23);
            this.label8.TabIndex = 7;
            this.label8.Text = "ZIP Code";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(32, 279);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 23);
            this.label9.TabIndex = 6;
            this.label9.Text = "City";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(32, 621);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 23);
            this.label10.TabIndex = 12;
            this.label10.Text = "Password";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(32, 573);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 23);
            this.label11.TabIndex = 11;
            this.label11.Text = "Email";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(32, 532);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 23);
            this.label12.TabIndex = 10;
            this.label12.Text = "Last Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(32, 495);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 23);
            this.label13.TabIndex = 9;
            this.label13.Text = "First Name";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(172, 49);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 29);
            this.textBox1.TabIndex = 13;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(172, 87);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 29);
            this.textBox2.TabIndex = 14;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox3.Location = new System.Drawing.Point(172, 122);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 29);
            this.textBox3.TabIndex = 15;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox4.Location = new System.Drawing.Point(172, 162);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 29);
            this.textBox4.TabIndex = 16;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox5.Location = new System.Drawing.Point(172, 200);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 29);
            this.textBox5.TabIndex = 17;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox6.Location = new System.Drawing.Point(172, 239);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 29);
            this.textBox6.TabIndex = 18;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox7.Location = new System.Drawing.Point(172, 363);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 29);
            this.textBox7.TabIndex = 21;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox8.Location = new System.Drawing.Point(172, 325);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 29);
            this.textBox8.TabIndex = 20;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox9.Location = new System.Drawing.Point(172, 283);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 29);
            this.textBox9.TabIndex = 19;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox10.Location = new System.Drawing.Point(154, 572);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 29);
            this.textBox10.TabIndex = 24;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox11.Location = new System.Drawing.Point(154, 536);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 29);
            this.textBox11.TabIndex = 23;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox12.Location = new System.Drawing.Point(154, 495);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 29);
            this.textBox12.TabIndex = 22;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox13.Location = new System.Drawing.Point(154, 621);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 29);
            this.textBox13.TabIndex = 25;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.WindowText;
            this.button1.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(67, 665);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 34);
            this.button1.TabIndex = 26;
            this.button1.Text = "Add Admin";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.MenuText;
            this.button2.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(64, 420);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(146, 38);
            this.button2.TabIndex = 27;
            this.button2.Text = "Add Client";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox16.Location = new System.Drawing.Point(154, 775);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 29);
            this.textBox16.TabIndex = 33;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox17.Location = new System.Drawing.Point(154, 732);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 29);
            this.textBox17.TabIndex = 32;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(32, 775);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(112, 23);
            this.label16.TabIndex = 29;
            this.label16.Text = "Last Name";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(32, 732);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 23);
            this.label17.TabIndex = 28;
            this.label17.Text = "First Name";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.WindowText;
            this.button3.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.SystemColors.Window;
            this.button3.Location = new System.Drawing.Point(67, 822);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(150, 38);
            this.button3.TabIndex = 34;
            this.button3.Text = "Add Vendor";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox18.Location = new System.Drawing.Point(531, 216);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 29);
            this.textBox18.TabIndex = 46;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox19.Location = new System.Drawing.Point(531, 176);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 29);
            this.textBox19.TabIndex = 45;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox20.Location = new System.Drawing.Point(531, 137);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 29);
            this.textBox20.TabIndex = 44;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox21.Location = new System.Drawing.Point(531, 93);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 29);
            this.textBox21.TabIndex = 43;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox22.Location = new System.Drawing.Point(531, 46);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 29);
            this.textBox22.TabIndex = 42;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(322, 258);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(190, 23);
            this.label15.TabIndex = 40;
            this.label15.Text = "Development Date";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(322, 216);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(106, 23);
            this.label18.TabIndex = 39;
            this.label18.Text = "Category";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(322, 182);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 23);
            this.label19.TabIndex = 38;
            this.label19.Text = "Rating";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(322, 143);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(122, 23);
            this.label20.TabIndex = 37;
            this.label20.Text = "Game Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(322, 100);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 23);
            this.label21.TabIndex = 36;
            this.label21.Text = "Admin ID";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(322, 52);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 23);
            this.label22.TabIndex = 35;
            this.label22.Text = "Vendor ID";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.WindowText;
            this.button4.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.SystemColors.Window;
            this.button4.Location = new System.Drawing.Point(397, 304);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(137, 39);
            this.button4.TabIndex = 49;
            this.button4.Text = "Add Game";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.WindowText;
            this.button5.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.SystemColors.Window;
            this.button5.Location = new System.Drawing.Point(785, 294);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(93, 42);
            this.button5.TabIndex = 62;
            this.button5.Text = "Rent";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox14.Location = new System.Drawing.Point(835, 211);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 29);
            this.textBox14.TabIndex = 60;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox15.Location = new System.Drawing.Point(835, 173);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 29);
            this.textBox15.TabIndex = 59;
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox23.Location = new System.Drawing.Point(835, 134);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 29);
            this.textBox23.TabIndex = 58;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox24.Location = new System.Drawing.Point(835, 91);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 29);
            this.textBox24.TabIndex = 57;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox25.Location = new System.Drawing.Point(835, 43);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 29);
            this.textBox25.TabIndex = 56;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label23.Location = new System.Drawing.Point(693, 213);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(116, 23);
            this.label23.TabIndex = 54;
            this.label23.Text = "Start Year";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(693, 176);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(136, 23);
            this.label24.TabIndex = 53;
            this.label24.Text = "Start Month";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(693, 137);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(103, 23);
            this.label25.TabIndex = 52;
            this.label25.Text = "Start Day";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(693, 94);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 23);
            this.label26.TabIndex = 51;
            this.label26.Text = "Game ID";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label27.Location = new System.Drawing.Point(693, 46);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 23);
            this.label27.TabIndex = 50;
            this.label27.Text = "Client ID";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.WindowText;
            this.button6.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button6.ForeColor = System.Drawing.SystemColors.Window;
            this.button6.Location = new System.Drawing.Point(754, 720);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(109, 42);
            this.button6.TabIndex = 71;
            this.button6.Text = "Rent Out";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox26.Location = new System.Drawing.Point(833, 571);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 29);
            this.textBox26.TabIndex = 70;
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox28.Location = new System.Drawing.Point(833, 527);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 29);
            this.textBox28.TabIndex = 68;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox29.Location = new System.Drawing.Point(833, 494);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 29);
            this.textBox29.TabIndex = 67;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(693, 574);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 23);
            this.label14.TabIndex = 66;
            this.label14.Text = "End Day";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(693, 528);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(95, 23);
            this.label29.TabIndex = 64;
            this.label29.Text = "Client ID";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(693, 493);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(110, 23);
            this.label30.TabIndex = 63;
            this.label30.Text = "Vendor ID";
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox30.Location = new System.Drawing.Point(833, 616);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 29);
            this.textBox30.TabIndex = 73;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(693, 616);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(118, 23);
            this.label31.TabIndex = 72;
            this.label31.Text = "End Month";
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox31.Location = new System.Drawing.Point(833, 663);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 29);
            this.textBox31.TabIndex = 75;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label32.Location = new System.Drawing.Point(693, 663);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(98, 23);
            this.label32.TabIndex = 74;
            this.label32.Text = "End Year";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gIDDataGridViewTextBoxColumn,
            this.vIDDataGridViewTextBoxColumn,
            this.aIDDataGridViewTextBoxColumn,
            this.gNAMEDataGridViewTextBoxColumn,
            this.rATINGDataGridViewTextBoxColumn,
            this.cATEGORYDataGridViewTextBoxColumn,
            this.dEVELOPDATEDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.gAMEBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(1021, 494);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(290, 204);
            this.dataGridView1.TabIndex = 76;
            // 
            // gIDDataGridViewTextBoxColumn
            // 
            this.gIDDataGridViewTextBoxColumn.DataPropertyName = "G_ID";
            this.gIDDataGridViewTextBoxColumn.HeaderText = "G_ID";
            this.gIDDataGridViewTextBoxColumn.Name = "gIDDataGridViewTextBoxColumn";
            this.gIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vIDDataGridViewTextBoxColumn
            // 
            this.vIDDataGridViewTextBoxColumn.DataPropertyName = "V_ID";
            this.vIDDataGridViewTextBoxColumn.HeaderText = "V_ID";
            this.vIDDataGridViewTextBoxColumn.Name = "vIDDataGridViewTextBoxColumn";
            // 
            // aIDDataGridViewTextBoxColumn
            // 
            this.aIDDataGridViewTextBoxColumn.DataPropertyName = "A_ID";
            this.aIDDataGridViewTextBoxColumn.HeaderText = "A_ID";
            this.aIDDataGridViewTextBoxColumn.Name = "aIDDataGridViewTextBoxColumn";
            // 
            // gNAMEDataGridViewTextBoxColumn
            // 
            this.gNAMEDataGridViewTextBoxColumn.DataPropertyName = "G_NAME";
            this.gNAMEDataGridViewTextBoxColumn.HeaderText = "G_NAME";
            this.gNAMEDataGridViewTextBoxColumn.Name = "gNAMEDataGridViewTextBoxColumn";
            // 
            // rATINGDataGridViewTextBoxColumn
            // 
            this.rATINGDataGridViewTextBoxColumn.DataPropertyName = "RATING";
            this.rATINGDataGridViewTextBoxColumn.HeaderText = "RATING";
            this.rATINGDataGridViewTextBoxColumn.Name = "rATINGDataGridViewTextBoxColumn";
            // 
            // cATEGORYDataGridViewTextBoxColumn
            // 
            this.cATEGORYDataGridViewTextBoxColumn.DataPropertyName = "CATEGORY";
            this.cATEGORYDataGridViewTextBoxColumn.HeaderText = "CATEGORY";
            this.cATEGORYDataGridViewTextBoxColumn.Name = "cATEGORYDataGridViewTextBoxColumn";
            // 
            // dEVELOPDATEDataGridViewTextBoxColumn
            // 
            this.dEVELOPDATEDataGridViewTextBoxColumn.DataPropertyName = "DEVELOP_DATE";
            this.dEVELOPDATEDataGridViewTextBoxColumn.HeaderText = "DEVELOP_DATE";
            this.dEVELOPDATEDataGridViewTextBoxColumn.Name = "dEVELOPDATEDataGridViewTextBoxColumn";
            // 
            // gAMEBindingSource
            // 
            this.gAMEBindingSource.DataMember = "GAME";
            this.gAMEBindingSource.DataSource = this.rentalDataSetBindingSource;
            // 
            // rentalDataSetBindingSource
            // 
            this.rentalDataSetBindingSource.DataSource = this.rentalDataSet;
            this.rentalDataSetBindingSource.Position = 0;
            // 
            // rentalDataSet
            // 
            this.rentalDataSet.DataSetName = "rentalDataSet";
            this.rentalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.WindowText;
            this.button7.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.SystemColors.Window;
            this.button7.Location = new System.Drawing.Point(1109, 719);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(130, 42);
            this.button7.TabIndex = 77;
            this.button7.Text = "Show Data";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox32.Location = new System.Drawing.Point(531, 255);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 29);
            this.textBox32.TabIndex = 78;
            // 
            // gAMETableAdapter
            // 
            this.gAMETableAdapter.ClearBeforeFill = true;
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox27.Location = new System.Drawing.Point(531, 719);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 29);
            this.textBox27.TabIndex = 91;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.WindowText;
            this.button8.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.button8.ForeColor = System.Drawing.SystemColors.Window;
            this.button8.Location = new System.Drawing.Point(407, 768);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(148, 33);
            this.button8.TabIndex = 90;
            this.button8.Text = "Update Game";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox33.Location = new System.Drawing.Point(531, 676);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 29);
            this.textBox33.TabIndex = 89;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox34.Location = new System.Drawing.Point(531, 637);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 29);
            this.textBox34.TabIndex = 88;
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox35.Location = new System.Drawing.Point(531, 599);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 29);
            this.textBox35.TabIndex = 87;
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox36.Location = new System.Drawing.Point(531, 566);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 29);
            this.textBox36.TabIndex = 86;
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox37.Location = new System.Drawing.Point(531, 526);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 29);
            this.textBox37.TabIndex = 85;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label28.Location = new System.Drawing.Point(322, 717);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(190, 23);
            this.label28.TabIndex = 84;
            this.label28.Text = "Development Date";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(322, 673);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(106, 23);
            this.label33.TabIndex = 83;
            this.label33.Text = "Category";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label34.Location = new System.Drawing.Point(322, 638);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(78, 23);
            this.label34.TabIndex = 82;
            this.label34.Text = "Rating";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(322, 599);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(122, 23);
            this.label35.TabIndex = 81;
            this.label35.Text = "Game Name";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label36.Location = new System.Drawing.Point(322, 566);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(96, 23);
            this.label36.TabIndex = 80;
            this.label36.Text = "Admin ID";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label37.Location = new System.Drawing.Point(322, 530);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(110, 23);
            this.label37.TabIndex = 79;
            this.label37.Text = "Vendor ID";
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.textBox38.Location = new System.Drawing.Point(531, 493);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 29);
            this.textBox38.TabIndex = 93;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label38.Location = new System.Drawing.Point(322, 495);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(88, 23);
            this.label38.TabIndex = 92;
            this.label38.Text = "Game ID";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("LEMON MILK Bold", 12F, System.Drawing.FontStyle.Bold);
            this.label39.Location = new System.Drawing.Point(1196, 830);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(205, 23);
            this.label39.TabIndex = 94;
            this.label39.Text = "BY MOHAMED GAMAL";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.WindowText;
            this.button9.Font = new System.Drawing.Font("LEMON MILK Bold", 7F, System.Drawing.FontStyle.Bold);
            this.button9.ForeColor = System.Drawing.SystemColors.Window;
            this.button9.Location = new System.Drawing.Point(969, 43);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(432, 32);
            this.button9.TabIndex = 95;
            this.button9.Text = "The most interesting game that had maximum number of renters ";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.WindowText;
            this.button10.Font = new System.Drawing.Font("LEMON MILK Bold", 7F, System.Drawing.FontStyle.Bold);
            this.button10.ForeColor = System.Drawing.SystemColors.Window;
            this.button10.Location = new System.Drawing.Point(969, 100);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(432, 32);
            this.button10.TabIndex = 96;
            this.button10.Text = "The games that hadn\'t any renters last month";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.WindowText;
            this.button11.Font = new System.Drawing.Font("LEMON MILK Bold", 7F, System.Drawing.FontStyle.Bold);
            this.button11.ForeColor = System.Drawing.SystemColors.Window;
            this.button11.Location = new System.Drawing.Point(969, 153);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(432, 32);
            this.button11.TabIndex = 97;
            this.button11.Text = "The Client with the maximum renting last month ";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.WindowText;
            this.button12.Font = new System.Drawing.Font("LEMON MILK Bold", 7F, System.Drawing.FontStyle.Bold);
            this.button12.ForeColor = System.Drawing.SystemColors.Window;
            this.button12.Location = new System.Drawing.Point(969, 201);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(432, 32);
            this.button12.TabIndex = 98;
            this.button12.Text = "The vendor with the maximum renting out last month";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.WindowText;
            this.button13.Font = new System.Drawing.Font("LEMON MILK Bold", 7F, System.Drawing.FontStyle.Bold);
            this.button13.ForeColor = System.Drawing.SystemColors.Window;
            this.button13.Location = new System.Drawing.Point(969, 255);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(432, 32);
            this.button13.TabIndex = 99;
            this.button13.Text = "The vendors whose games hadn\'t any renting last month";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.WindowText;
            this.button14.Font = new System.Drawing.Font("LEMON MILK Bold", 7F, System.Drawing.FontStyle.Bold);
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(969, 304);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(432, 32);
            this.button14.TabIndex = 100;
            this.button14.Text = "The vendors who didn\'t add any game last year ";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1413, 881);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "GameRental";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gAMEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rentalDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.BindingSource rentalDataSetBindingSource;
        private rentalDataSet rentalDataSet;
        private System.Windows.Forms.BindingSource gAMEBindingSource;
        private rentalDataSetTableAdapters.GAMETableAdapter gAMETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn gIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gNAMEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rATINGDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cATEGORYDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dEVELOPDATEDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
    }
}

